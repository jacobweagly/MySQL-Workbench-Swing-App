/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testing_only;

import cosc.pkg457.project.WFrame;
import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*; 

public class SamplePanel2 extends Panel implements ActionListener{  
    private WFrame f;  
    private JButton b;  
    private JTextArea ta;  
    SamplePanel2(WFrame f){  
        this.f = f;
        b=new JButton("Pad Color");  
        b.setBounds(200,250,100,30);
        b.addActionListener(this);  
        add(b);
        ta=new JTextArea();  
        ta.setBounds(10,10,300,200);  
        add(ta);  
        setSize(f.size());
        setLayout(null);  
        f.add(this);
        hide();
    }  
    public void actionPerformed(ActionEvent e){  
        Color c=JColorChooser.showDialog(this,"Choose",Color.CYAN);  
        ta.setBackground(c);  
        hide();
        f.getSamplePanel3().show();
    }  
} 
