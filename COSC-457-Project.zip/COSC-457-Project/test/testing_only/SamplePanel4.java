/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testing_only;

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*; 

//DOESNT WORK AS INTENDED

public class SamplePanel4 extends Panel implements ActionListener{
    JFrame f;  
    JButton b;  
    JTextArea ta;  
    SamplePanel4(JFrame f){  
        this.f = f;
        b=new JButton("Pad Color");  
        b.setBounds(200,350,30,30);  
        ta=new JTextArea();  
        ta.setBounds(10,400,300,30);  
        b.addActionListener(this);  
        f.add(b);f.add(ta);  
        f.setLayout(null);  
    }  
    public void actionPerformed(ActionEvent e){  
        Color c=JColorChooser.showDialog(this,"Choose",Color.CYAN);  
        ta.setBackground(c);  
    }  
} 
