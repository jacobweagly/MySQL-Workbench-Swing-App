/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc.pkg457.project;

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*; 

public class RentalGuns extends Panel implements ActionListener{  
    private WFrame f;  
    private JTextArea ta1;  
    private JButton b1;
    private JButton b2;  
    private JButton b3;  
    private JButton b4;
    private JButton b5;
    RentalGuns(WFrame f){  
        this.f = f;
        ta1=new JTextArea();  
        ta1.setBounds(100,10,800,300);
        ta1.setEditable(false);
        add(ta1);  
        b1=new JButton("Most Popular Guns By Unit Number");  
        b1.setBounds(100,330,250,30);
        b1.addActionListener(this);  
        add(b1);
        b4=new JButton("Most Popular Guns By Brand");  
        b4.setBounds(375,330,250,30);
        b4.addActionListener(this);  
        add(b4);
        b5=new JButton("Most Popular Guns By Gauge");  
        b5.setBounds(650,330,250,30);
        b5.addActionListener(this);  
        add(b5);
        b2=new JButton("Back");  
        b2.setBounds(10,330,80,30);
        b2.addActionListener(this);  
        add(b2);
        b3=new JButton("Quit");  
        b3.setBounds(10,10,80,30);
        b3.addActionListener(this);  
        add(b3);
        setSize(f.size());
        setLayout(null);  
        f.add(this);
        hide();
    }  
    public void actionPerformed(ActionEvent e){  
        String selection = ((JButton)e.getSource()).getText();
        switch (selection){
            case "Most Popular Guns By Unit Number":
                String[] inv1 = f.getConnection().selectQuery("select unitNum, roundsUsed " +
                                                            "from jweagl2db.rentalguns " +
                                                            "group by unitNum " +
                                                            "order by roundsUsed desc; "); //TYPE SQL HERE
                ta1.setText("");
                for(int i = 0; i < inv1.length; i++){
                    ta1.append(inv1[i] + "\n");
                }
                break;
            case "Most Popular Guns By Brand":
                String[] inv4 = f.getConnection().selectQuery("select brand, SUM(roundsUsed) " +
                                                            "from jweagl2db.rentalguns " +
                                                            "group by brand " +
                                                            "order by roundsUsed desc; "); //TYPE SQL HERE
                ta1.setText("");
                for(int i = 0; i < inv4.length; i++){
                    ta1.append(inv4[i] + "\n");
                }
                break;
            case "Most Popular Guns By Gauge":
                String[] inv5 = f.getConnection().selectQuery("select guage, SUM(roundsUsed) " +
                                                            "from jweagl2db.rentalguns " +
                                                            "group by guage " +
                                                            "order by roundsUsed desc; "); //TYPE SQL HERE
                ta1.setText("");
                for(int i = 0; i < inv5.length; i++){
                    ta1.append(inv5[i] + "\n");
                }
                break;
            case "Back":
                hide();
                f.getMainMenu().show();
                break;
            case "Quit":
                f.dispose();
                break;
        }
    }  
} 