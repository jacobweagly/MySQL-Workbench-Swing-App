/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc.pkg457.project;

/**
 *
 * @author Jacob Weagly
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class WFrame extends JFrame{
    
    // Frame's different screens (panels)
    private Panel[] screens;
 
    // Frame's SQL Connection
    private SQLConnection connection;
    
    public WFrame(String s){
        super(s);
        connection = new SQLConnection();
    }
    
    public void populate(){
        setBounds(0, 0, 1000, 500);
        screens = new Panel[11];
        screens[0] = new MainMenu(this);
        screens[1] = new ShowInventory(this);
        screens[2] = new CountSearch(this);
        screens[3] = new GamesByPopularity(this);
        screens[4] = new GamesByTargetLosses(this);
        screens[5] = new AmmoByPopularity(this);
        screens[6] = new Fields(this);
        screens[7] = new RentalGuns(this);
        screens[8] = new ListTrailers(this);
        screens[9] = new StolenGoods(this);
        screens[10] = new InsertData(this);
    }
    
    public Panel getMainMenu(){
        return screens[0];
    }
    
    public Panel getShowInventory(){
        return screens[1];
    }
    
    public Panel getCountSearch(){
        return screens[2];
    }
    
    public Panel getGamesByPopularity(){
        return screens[3];
    }
    
    public Panel getGamesByTargetLosses(){
        return screens[4];
    }
    
    public Panel getAmmoByPopularity(){
        return screens[5];
    }
    
    public Panel getFields(){
        return screens[6];
    }
    
    public Panel getRentalGuns(){
        return screens[7];
    }
    
    public Panel getListTrailers(){
        return screens[8];
    }
    
    public Panel getStolenGoods(){
        return screens[9];
    }
    
    public Panel getInsertData(){
        return screens[10];
    }
    
    public SQLConnection getConnection(){
        return connection;
    }
}
