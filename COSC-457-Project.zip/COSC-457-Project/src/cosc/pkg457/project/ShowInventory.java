/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc.pkg457.project;

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*; 

public class ShowInventory extends Panel implements ActionListener{  
    private WFrame f;  
    private JTextArea ta1;  
    private JButton b1;
    private JButton b2;  
    private JButton b3;  
    ShowInventory(WFrame f){  
        this.f = f;
        ta1=new JTextArea();  
        ta1.setBounds(100,10,800,300);
        ta1.setEditable(false);
        add(ta1);  
        b1=new JButton("Show Inventory");  
        b1.setBounds(100,330,800,30);
        b1.addActionListener(this);  
        add(b1);
        b2=new JButton("Back");  
        b2.setBounds(10,330,80,30);
        b2.addActionListener(this);  
        add(b2);
        b3=new JButton("Quit");  
        b3.setBounds(10,10,80,30);
        b3.addActionListener(this);  
        add(b3);
        setSize(f.size());
        setLayout(null);  
        f.add(this);
        hide();
    }  
    public void actionPerformed(ActionEvent e){  
        String selection = ((JButton)e.getSource()).getText();
        switch (selection){
            case "Show Inventory":
                String[] inv = f.getConnection().selectQuery("select ROUND((ROUND(SUM(skeet.hEndNum + skeet.lEndNum)/25) - rounds.qty)/25) " +
                                                            "from jweagl2db.skeet, jweagl2db.rounds " +
                                                            "where rounds.gameType = 'skeet'; "); //TYPE SQL HERE
                for(int i = 0; i < inv.length; i++){
                    ta1.append(inv[i] + "\n");
                }
                break;
            case "Back":
                hide();
                f.getMainMenu().show();
                break;
            case "Quit":
                f.dispose();
                break;
        }
    }  
} 
