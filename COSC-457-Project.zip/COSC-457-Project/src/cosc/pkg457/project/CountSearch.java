/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc.pkg457.project;

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*; 

public class CountSearch extends Panel implements ActionListener{  
    private WFrame f;  
    private JTextArea ta1;  
    private JTextArea ta2; 
    private JButton b1;
    private JButton b2;  
    private JButton b3;
    private JButton b4;
    private JButton b5;  
    private JButton b6;
    CountSearch(WFrame f){  
        this.f = f;
        ta1=new JTextArea();  
        ta1.setBounds(100,10,800,30);
        ta1.setEditable(false);
        ta1.setText("Start of month: ");
        add(ta1);  
        ta2=new JTextArea();  
        ta2.setBounds(100,50,800,30);
        ta2.setEditable(false);
        ta2.setText("End of month: ");
        add(ta2);  
        b1=new JButton("Count Targets");  
        b1.setBounds(100,100,800,30);
        b1.addActionListener(this);  
        add(b1);
        b2=new JButton("Count Ammunition");  
        b2.setBounds(100,140,800,30);
        b2.addActionListener(this);  
        add(b2);
        b3=new JButton("Count Machines");  
        b3.setBounds(100,180,800,30);
        b3.addActionListener(this);  
        add(b3);
        b4=new JButton("Count Games");  
        b4.setBounds(100,220,800,30);
        b4.addActionListener(this);  
        add(b4);
        b5=new JButton("Back");  
        b5.setBounds(10,100,80,30);
        b5.addActionListener(this);  
        add(b5);
        b6=new JButton("Quit");  
        b6.setBounds(10,10,80,30);
        b6.addActionListener(this);  
        add(b6);
        setSize(f.size());
        setLayout(null);  
        f.add(this);
        hide();
    }  
    public void actionPerformed(ActionEvent e){  
        String selection = ((JButton)e.getSource()).getText();
        switch (selection){
            case "Count Targets":
                String[] targetCountStart = f.getConnection().selectQuery("SELECT <query> FROM <some table>"); //TYPE SQL HERE
                String[] targetCountEnd = f.getConnection().selectQuery("SELECT <query> FROM <some table>"); //TYPE SQL HERE
                ta1.setText("Start of month: " + targetCountStart[0]);
                ta2.setText("End of month: " + targetCountEnd[0]);
                break;
            case "Count Ammunition":
                String[] AmmoCountStart = f.getConnection().selectQuery("SELECT <query> FROM <some table>"); //TYPE SQL HERE
                String[] AmmoCountEnd = f.getConnection().selectQuery("SELECT <query> FROM <some table>"); //TYPE SQL HERE
                ta1.setText("Start of month: " + AmmoCountStart[0]);
                ta2.setText("End of month: " + AmmoCountEnd[0]);
                break;
            case "Count Machines":
                String[] machineCountStart = f.getConnection().selectQuery("SELECT <query> FROM <some table>"); //TYPE SQL HERE
                String[] machineCountEnd = f.getConnection().selectQuery("SELECT <query> FROM <some table>"); //TYPE SQL HERE
                ta1.setText("Start of month: " + machineCountStart[0]);
                ta2.setText("End of month: " + machineCountEnd[0]);
                break;
            case "Count Games":
                String[] gameCountStart = f.getConnection().selectQuery("SELECT <query> FROM <some table>"); //TYPE SQL HERE
                String[] gameCountEnd = f.getConnection().selectQuery("SELECT <query> FROM <some table>"); //TYPE SQL HERE
                ta1.setText("Start of month: " + gameCountStart[0]);
                ta2.setText("End of month: " + gameCountEnd[0]);
                break;
            case "Back":
                hide();
                f.getMainMenu().show();
                break;
            case "Quit":
                f.dispose();
                break;
        }
    }  
} 
