/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc.pkg457.project;

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*; 

public class Fields extends Panel implements ActionListener{  
    private WFrame f;  
    private JTextArea ta1;  
    private JButton b1;
    private JButton b2;  
    private JButton b3;  
    private JButton b4;
    private JButton b5;
    private JButton b6;
    private JButton b7;
    private JButton b8;
    Fields(WFrame f){  
        this.f = f;
        ta1=new JTextArea();  
        ta1.setBounds(100,10,800,300);
        ta1.setEditable(false);
        add(ta1);  
        b1=new JButton("Skeet Fields By Popularity");  
        b1.setBounds(100,330,250,30);
        b1.addActionListener(this);  
        add(b1);
        b4=new JButton("Trapp Fields By Popularity");  
        b4.setBounds(375,330,250,30);
        b4.addActionListener(this);  
        add(b4);
        b5=new JButton("Fivestand Fields By Popularity");  
        b5.setBounds(650,330,250,30);
        b5.addActionListener(this);  
        add(b5);
        b6=new JButton("Skeet Fields By Stock");  
        b6.setBounds(100,370,250,30);
        b6.addActionListener(this);  
        add(b6);
        b7=new JButton("Trapp Fields By Stock");  
        b7.setBounds(375,370,250,30);
        b7.addActionListener(this);  
        add(b7);
        b8=new JButton("Fivestand Fields By Stock");  
        b8.setBounds(650,370,250,30);
        b8.addActionListener(this);  
        add(b8);
        b2=new JButton("Back");  
        b2.setBounds(10,330,80,30);
        b2.addActionListener(this);  
        add(b2);
        b3=new JButton("Quit");  
        b3.setBounds(10,10,80,30);
        b3.addActionListener(this);  
        add(b3);
        setSize(f.size());
        setLayout(null);  
        f.add(this);
        hide();
    }  
    public void actionPerformed(ActionEvent e){  
        String selection = ((JButton)e.getSource()).getText();
        switch (selection){
            case "Skeet Fields By Popularity":
                String[] inv1 = f.getConnection().selectQuery("select fieldNum, SUM(hEndNum + lEndNum) " +
                                                            "from jweagl2db.skeet " +
                                                            "group by fieldNum " +
                                                            "order by SUM(hEndNum + lEndNum) desc; "); //TYPE SQL HERE
                ta1.setText("");
                for(int i = 0; i < inv1.length; i++){
                    ta1.append(inv1[i] + "\n");
                }
                break;
            case "Trapp Fields By Popularity":
                String[] inv4 = f.getConnection().selectQuery("select fieldMachine, endNumber " +
                                                            "from jweagl2db.trapp " +
                                                            "group by fieldMachine " +
                                                            "order by endNumber desc; "); //TYPE SQL HERE
                ta1.setText("");
                for(int i = 0; i < inv4.length; i++){
                    ta1.append(inv4[i] + "\n");
                }
                break;
            case "Fivestand Fields By Popularity":
                String[] inv5 = f.getConnection().selectQuery("select machine, endNumber, targetsType " +
                                                            "from jweagl2db.fivestand " +
                                                            "group by machine " +
                                                            "order by endNumber desc; "); //TYPE SQL HERE
                ta1.setText("");
                for(int i = 0; i < inv5.length; i++){
                    ta1.append(inv5[i] + "\n");
                }
                break;
            case "Skeet Fields By Stock":
                String[] inv6 = f.getConnection().selectQuery("select SUM(hBoxes + lBoxes), fieldNum " +
                                                            "from jweagl2db.skeet " +
                                                            "group by fieldNum " +
                                                            "order by SUM(hBoxes + lBoxes) desc; "); //TYPE SQL HERE
                ta1.setText("");
                for(int i = 0; i < inv6.length; i++){
                    ta1.append(inv6[i] + "\n");
                }
                break;
            case "Trapp Fields By Stock":
                String[] inv7 = f.getConnection().selectQuery("select fieldMachine, boxes " +
                                                            "from jweagl2db.trapp " +
                                                            "group by fieldMachine " +
                                                            "order by boxes desc; "); //TYPE SQL HERE
                ta1.setText("");
                for(int i = 0; i < inv7.length; i++){
                    ta1.append(inv7[i] + "\n");
                }
                break;
            case "Fivestand Fields By Stock":
                String[] inv8 = f.getConnection().selectQuery("select machine, targets " +
                                                            "from jweagl2db.fivestand " +
                                                            "group by machine " +
                                                            "order by targets desc; "); //TYPE SQL HERE
                ta1.setText("");
                for(int i = 0; i < inv8.length; i++){
                    ta1.append(inv8[i] + "\n");
                }
                break;
            case "Back":
                hide();
                f.getMainMenu().show();
                break;
            case "Quit":
                f.dispose();
                break;
        }
    }  
} 