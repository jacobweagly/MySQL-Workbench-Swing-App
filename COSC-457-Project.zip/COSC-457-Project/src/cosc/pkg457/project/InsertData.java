/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc.pkg457.project;

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*; 

public class InsertData extends Panel implements ActionListener{  
    private WFrame f;  
    private JLabel lb1;
    private JLabel lb2;
    private JTextArea ta1;  
    private JButton b1;
    private JButton b2;  
    private JButton b3; 
    private JButton b4;
    private JButton b5;
    private JButton b6;
    private JButton b7;
    private JButton b8;
    private JButton b9;
    private JButton b10;
    private JButton b11;
    private JButton b12;
    private JButton b13;
    private JButton b14;
    private JButton b15;
    private JButton b16;
    InsertData(WFrame f){  
        this.f = f;
        lb1 = new JLabel();
        lb1.setBounds(115,330,600,30);
        lb1.setText("Insert data parameters separated by commas w/ no space. Visit manual for parameter instructions.");
        add(lb1);
        lb2 = new JLabel();
        lb2.setBounds(115,380,600,30);
        lb2.setText("To delete data, enter in the ID number and click 'Delete From <desired table>'.");
        add(lb2);
        ta1=new JTextArea();  
        ta1.setBounds(100,10,800,30);
        add(ta1);  
        b1=new JButton("Insert Into Ammo");  // insert into ammo (product_id, guage, brand, size, qtySold) values ('e13', '12', 'estate','6', '1'); 
        b1.setBounds(100,50,200,30);
        b1.addActionListener(this);  
        add(b1);
        b4=new JButton("Insert Into Fivestand");  // insert into fivestand (machine, targets, targetsType, endNumber) values (20, 416, 'midi',0);
        b4.setBounds(100,90,200,30);
        b4.addActionListener(this);  
        add(b4);
        b5=new JButton("Insert Into Rental Guns");  // insert into rentalguns (unitNum, brand, guage, actionType, roundsUsed) values ('rsa1', 'Remington', 12,'Semi', 0);
        b5.setBounds(100,130,200,30);
        b5.addActionListener(this);  
        add(b5);
        b6=new JButton("Insert Into Rounds"); // insert into rounds (gameType, qty) values ('sporting-clays', 500);  
        b6.setBounds(100,170,200,30);
        b6.addActionListener(this);  
        add(b6);
        b7=new JButton("Insert Into Skeet");  // insert into skeet (fieldNum, hEndNum, lEndNum, hBoxes, lBoxes, hTargets, lTargets) values (8, 900, 900, 15, 12, 636, 636);
        b7.setBounds(100,210,200,30);
        b7.addActionListener(this);  
        add(b7);
        b8=new JButton("Insert Into Trapp");  // insert into trapp (fieldMachine, endNumber, boxes, targets) values (4, 2500, 13, 544);
        b8.setBounds(100,250,200,30);
        b8.addActionListener(this);  
        add(b8);
        b9=new JButton("Insert Into Trailer");  // insert into trailer (trailerNumber, palletNumber, boxes, targetType) values (4, 0, 35, 'regular'); // " + variables[] + "
        b9.setBounds(100,290,200,30);
        b9.addActionListener(this);  
        add(b9);
        
        b10=new JButton("Delete From Ammo");  // insert into ammo (product_id, guage, brand, size, qtySold) values ('e13', '12', 'estate','6', '1'); 
        b10.setBounds(325,50,200,30);
        b10.addActionListener(this);  
        add(b10);
        b11=new JButton("Delete From Fivestand");  // insert into fivestand (machine, targets, targetsType, endNumber) values (20, 416, 'midi',0);
        b11.setBounds(325,90,200,30);
        b11.addActionListener(this);  
        add(b11);
        b12=new JButton("Delete From Rental Guns");  // insert into rentalguns (unitNum, brand, guage, actionType, roundsUsed) values ('rsa1', 'Remington', 12,'Semi', 0);
        b12.setBounds(325,130,200,30);
        b12.addActionListener(this);  
        add(b12);
        b13=new JButton("Delete From Rounds"); // insert into rounds (gameType, qty) values ('sporting-clays', 500);  
        b13.setBounds(325,170,200,30);
        b13.addActionListener(this);  
        add(b13);
        b14=new JButton("Delete From Skeet");  // insert into skeet (fieldNum, hEndNum, lEndNum, hBoxes, lBoxes, hTargets, lTargets) values (8, 900, 900, 15, 12, 636, 636);
        b14.setBounds(325,210,200,30);
        b14.addActionListener(this);  
        add(b14);
        b15=new JButton("Delete From Trapp");  // insert into trapp (fieldMachine, endNumber, boxes, targets) values (4, 2500, 13, 544);
        b15.setBounds(325,250,200,30);
        b15.addActionListener(this);  
        add(b15);
        b16=new JButton("Delete From Trailer");  // insert into trailer (trailerNumber, palletNumber, boxes, targetType) values (4, 0, 35, 'regular'); // " + variables[] + "
        b16.setBounds(325,290,200,30);
        b16.addActionListener(this);  
        add(b16);
        
        b2=new JButton("Back");  
        b2.setBounds(10,330,80,30);
        b2.addActionListener(this);  
        add(b2);
        b3=new JButton("Quit");  
        b3.setBounds(10,10,80,30);
        b3.addActionListener(this);  
        add(b3);
        setSize(f.size());
        setLayout(null);  
        f.add(this);
        hide();
    }  
    public void actionPerformed(ActionEvent e){  
        String selection = ((JButton)e.getSource()).getText();
        // For deletion
        String[] variables;
        String q;
        switch (selection){
            case "Insert Into Ammo":
                String[] variables1 = ta1.getText().split(",");
                ta1.setText("");
                String q1 = "insert into jweagl2db.Ammo (product_id, guage, brand, size, qtySold) values ('" + variables1[0] + "', '" + variables1[1] + "', '" + variables1[2] + "','" + variables1[3] + "', '" + variables1[4] + "');";
                f.getConnection().updateQuery(q1);
                break;
            case "Insert Into Fivestand":
                String[] variables4 = ta1.getText().split(",");
                ta1.setText("");
                String q4 = "insert into jweagl2db.fivestand (machine, targets, targetsType, endNumber) values (" + variables4[0] + ", " + variables4[1] + ", '" + variables4[2] + "'," + variables4[3] + ");";
                f.getConnection().updateQuery(q4);
                break;
            case "Insert Into Rental Guns":
                String[] variables5 = ta1.getText().split(",");
                ta1.setText("");
                String q5 = "insert into jweagl2db.rentalguns (unitNum, brand, guage, actionType, roundsUsed) values ('" + variables5[0] + "', '" + variables5[1] + "', " + variables5[2] + ",'" + variables5[3] + "', " + variables5[4] + ");";
                f.getConnection().updateQuery(q5);
                break;
            case "Insert Into Rounds":
                String[] variables6 = ta1.getText().split(",");
                ta1.setText("");
                String q6 = "insert into jweagl2db.rounds (gameType, qty) values ('" + variables6[0] + "', " + variables6[1] + ");";
                f.getConnection().updateQuery(q6);
                break;
            case "Insert Into Skeet":
                String[] variables7 = ta1.getText().split(",");
                ta1.setText("");
                String q7 = "insert into jweagl2db.skeet (fieldNum, hEndNum, lEndNum, hBoxes, lBoxes, hTargets, lTargets) values (" + variables7[0] + ", " + variables7[1] + ", " + variables7[2] + ", " + variables7[3] + ", " + variables7[4] + ", " + variables7[5] + ", " + variables7[6] + ");";
                f.getConnection().updateQuery(q7);
                break;
            case "Insert Into Trapp":
                String[] variables8 = ta1.getText().split(",");
                ta1.setText("");
                String q8 = "insert into jweagl2db.trapp (fieldMachine, endNumber, boxes, targets) values (" + variables8[0] + ", " + variables8[1] + ", " + variables8[2] + ", " + variables8[3] + ");";
                f.getConnection().updateQuery(q8);
                break;
            case "Insert Into Trailer":
                String[] variables9 = ta1.getText().split(",");
                ta1.setText("");
                String q9 = "insert into jweagl2db.trailer (trailerNumber, palletNumber, boxes, targetType) values (" + variables9[0] + ", " + variables9[1] + ", " + variables9[2] + ", '" + variables9[3] + "');";
                f.getConnection().updateQuery(q9);
                break; // queries from here use the same string variables
                
            case "Delete From Ammo":
                variables = ta1.getText().split(",");
                ta1.setText("");
                q = "DELETE FROM jweagl2db.Ammo WHERE product_id = '" + variables[0] + "'";
                f.getConnection().updateQuery(q);
                break;
            case "Delete From Fivestand":
                variables = ta1.getText().split(",");
                ta1.setText("");
                q = "DELETE FROM jweagl2db.fivestand WHERE machine = '" + variables[0] + "'";
                f.getConnection().updateQuery(q);
                break;
            case "Delete From Rental Guns":
                variables = ta1.getText().split(",");
                ta1.setText("");
                q = "DELETE FROM jweagl2db.rentalguns WHERE unitNum = '" + variables[0] + "'";
                f.getConnection().updateQuery(q);
                break;
            case "Delete From Rounds":
                variables = ta1.getText().split(",");
                ta1.setText("");
                q = "DELETE FROM jweagl2db.rounds WHERE gameType = '" + variables[0] + "'";
                f.getConnection().updateQuery(q);
                break;
            case "Delete From Skeet":
                variables = ta1.getText().split(",");
                ta1.setText("");
                q = "DELETE FROM jweagl2db.skeet WHERE fieldNum = '" + variables[0] + "'";
                f.getConnection().updateQuery(q);
                break;
            case "Delete From Trapp":
                variables = ta1.getText().split(",");
                ta1.setText("");
                q = "DELETE FROM jweagl2db.trapp WHERE fieldmachine = '" + variables[0] + "'";
                f.getConnection().updateQuery(q);
                break;
            case "Delete From Trailer":
                variables = ta1.getText().split(",");
                ta1.setText("");
                q = "DELETE FROM jweagl2db.trailer WHERE trailerNumber = '" + variables[0] + "'";
                f.getConnection().updateQuery(q);
                break; 
                
            case "Back":
                hide();
                f.getMainMenu().show();
                break;
            case "Quit":
                f.dispose();
                break;
        }
    }  
} 
