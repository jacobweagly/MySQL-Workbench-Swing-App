/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc.pkg457.project;

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*; 

public class StolenGoods extends Panel implements ActionListener{  
    private WFrame f;  
    private JTextArea ta1;  
    private JButton b1;
    private JButton b2;  
    private JButton b3;  
    StolenGoods(WFrame f){  
        this.f = f;
        ta1=new JTextArea();  
        ta1.setBounds(100,10,800,300);
        ta1.setEditable(false);
        add(ta1);  
        b1=new JButton("Show Stolen Rounds");  
        b1.setBounds(100,330,250,30);
        b1.addActionListener(this);  
        add(b1);
        b2=new JButton("Back");  
        b2.setBounds(10,330,80,30);
        b2.addActionListener(this);  
        add(b2);
        b3=new JButton("Quit");  
        b3.setBounds(10,10,80,30);
        b3.addActionListener(this);  
        add(b3);
        setSize(f.size());
        setLayout(null);  
        f.add(this);
        hide();
    }  
    public void actionPerformed(ActionEvent e){  
        String selection = ((JButton)e.getSource()).getText();
        switch (selection){
            case "Show Stolen Rounds":  //COMPLICATED QUERY
                String[] inv1 = f.getConnection().selectQuery("select ROUND((ROUND(SUM(skeet.hEndNum + skeet.lEndNum)/25) - rounds.qty)/25) " +
                                                            "from jweagl2db.skeet, jweagl2db.rounds " +
                                                            "where rounds.gameType = 'skeet'; ");
                String[] inv2 = f.getConnection().selectQuery("select ROUND(ROUND(SUM(endNumber)/25) - rounds.qty/25) " +
                                                            "from jweagl2db.trapp, jweagl2db.rounds " +
                                                            "where rounds.gameType = 'trapp'; ");
                String[] inv3 = f.getConnection().selectQuery("select ROUND((ROUND(SUM(endnumber)/25)-rounds.qty)/25) " +
                                                            "from jweagl2db.fivestand, jweagl2db.rounds " +
                                                            "where gameType = 'fiveStand'; ");
                ta1.setText("");
                ta1.append("Stolen skeet rounds :" + inv1[1] + "\n\n");
                ta1.append("Stolen trapp rounds: " + inv2[1] + "\n\n");
                ta1.append("Stolen fivestand rounds: " + inv3[1] + "\n\n");
                break;
            case "Back":
                hide();
                f.getMainMenu().show();
                break;
            case "Quit":
                f.dispose();
                break;
        }
    }  
} 