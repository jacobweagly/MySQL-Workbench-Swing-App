/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc.pkg457.project;

import java.sql.*;
/**
 *
 * @author Jacob Weagly
 */
public class SQLConnection { // CONNECT TO DATABASE HERE
    public SQLConnection(){
        
    }
    
    public String[] selectQuery(String query){ // CONNECT TO DATABASE HERE
        String[] result = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
        }catch(ClassNotFoundException e){
            System.out.println(e);
        }
        
        final String ID = "jweagl2";
        final String PW = "COSC*c730q";
        final String SERVER = "jdbc:mysql://triton.towson.edu:3360/?serverTimezone=EST#/" + ID + "db";
        
        try{
            Connection con = DriverManager.getConnection(SERVER, ID, PW);
            Statement stmt = con.createStatement();
            
            ResultSet rs = stmt.executeQuery(query);   
            int rowCount = 0;
            while(rs.next()){ 
                rowCount++;
            }
            result = new String[rowCount + 1];
            result[0] = "";
            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++){        
                result[0] = result[0] + rs.getMetaData().getColumnName(i) + "\t\t";
            }
            //result[0] = result[0].substring(0, result[0].length() - 2);
            
            int i = 1;
            rs.beforeFirst();
            while(rs.next()){ 
                result[i] = "";
                for(int j = 0; j < result[0].split("\t\t").length; j++){
                    result[i] = result[i] + rs.getString(result[0].split("\t\t")[j]) + "\t\t";
                }
                //result[i] = result[i].substring(0, result[i].length() - 2);
                i++;
            }
            
        }catch(SQLException e){
            System.err.println(e);
        }
        return result;
    }
    
    public void updateQuery(String query){ // CONNECT TO DATABASE HERE
        try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        }catch (ClassNotFoundException e){
            System.out.println(e);
        }
        final String ID = "jweagl2";
        final String PW = "COSC*c730q";
        final String SERVER = "jdbc:mysql://triton.towson.edu:3360/?serverTimezone=EST#/" + ID + "db";
        try {
            Connection con = DriverManager.getConnection(SERVER, ID, PW);
            PreparedStatement updateStaff = null;
            updateStaff = con.prepareStatement(query);
            updateStaff.executeUpdate();
        }catch (SQLException e){
            System.err.println(e);
        }

    }
}
