/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc.pkg457.project;

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*; 

public class MainMenu extends Panel implements ActionListener{  
    private WFrame f;  
    private JButton b1;  
    private JButton b2;
    private JButton b3;
    private JButton b4;
    private JButton b5;
    private JButton b6;
    private JButton b7;
    private JButton b8;
    MainMenu(WFrame f){  
        this.f = f;
        b1=new JButton("List Games By Popularity");
        b1.setBounds(100,50,800,30);
        b1.addActionListener(this);  
        add(b1);
        b2=new JButton("List Ammo By Popularity");
        b2.setBounds(100,90,800,30);
        b2.addActionListener(this);  
        add(b2);
        b3=new JButton("List Fields");  
        b3.setBounds(100,130,800,30);
        b3.addActionListener(this);  
        add(b3);
        b4=new JButton("List Rental Guns");  
        b4.setBounds(100,170,800,30);
        b4.addActionListener(this);  
        add(b4);
        b5=new JButton("List Trailers");  
        b5.setBounds(100,210,800,30);
        b5.addActionListener(this);  
        add(b5);
        b7=new JButton("Stolen Rounds");  
        b7.setBounds(100,250,800,30);
        b7.addActionListener(this);  
        add(b7);
        b8=new JButton("Insert Data");  
        b8.setBounds(100,290,800,30);
        b8.addActionListener(this);  
        add(b8);
        b6=new JButton("Quit");  
        b6.setBounds(10,10,80,30);
        b6.addActionListener(this);  
        add(b6);
        setSize(f.size());
        setLayout(null);  
        f.add(this);
    }  
    public void actionPerformed(ActionEvent e){  
        String selection = ((JButton)e.getSource()).getText();
        switch (selection){
            case "List Games By Popularity":
                hide();
                f.getGamesByPopularity().show();
                break;
            case "List Ammo By Popularity":
                hide();
                f.getAmmoByPopularity().show();
                break;
            case "List Fields":
                hide();
                f.getFields().show();
                break;
            case "List Rental Guns":
                hide();
                f.getRentalGuns().show();
                break;
            case "List Trailers":
                hide();
                f.getListTrailers().show();
                break;
            case "Stolen Rounds":
                hide();
                f.getStolenGoods().show();
                break;
            case "Insert Data":
                hide();
                f.getInsertData().show();
                break;
            case "Quit":
                //f.getConnection().updateQuery("INSERT INTO jweagl2db.test (`idtest`, `name`) VALUES ('501', 'tester');");
                f.dispose();
                break;
        }
    }  
} 
